export default function TestSuccessPage() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Payment successful ✅</h1>
      <p>Your subscription will be activated shortly.</p>
    </div>
  )
}

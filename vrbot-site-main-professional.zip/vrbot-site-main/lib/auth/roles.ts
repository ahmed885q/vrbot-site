export type UserRole = 'admin' | 'user'

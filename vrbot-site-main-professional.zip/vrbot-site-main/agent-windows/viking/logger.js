const fs = require('fs')
const path = require('path')

const LOG_PATH = path.join(__dirname, '..', 'agent-runtime.log')

function nowIso() {
  return new Date().toISOString()
}

function writeLine(line) {
  try {
    fs.appendFileSync(LOG_PATH, line + '\n', 'utf8')
  } catch {
    // ignore
  }
}

function log(level, msg, data) {
  const entry = { ts: nowIso(), level, msg, data }
  writeLine(JSON.stringify(entry))
  if (level === 'error') {
    console.error(`[${entry.ts}] [${level}] ${msg}`, data || '')
  } else {
    console.log(`[${entry.ts}] [${level}] ${msg}`)
  }
}

module.exports = {
  log,
  info: (m, d) => log('info', m, d),
  warn: (m, d) => log('warn', m, d),
  error: (m, d) => log('error', m, d),
  LOG_PATH,
}

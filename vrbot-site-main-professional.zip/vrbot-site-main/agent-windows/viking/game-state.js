const fs = require('fs')
const path = require('path')
const { info, warn } = require('./logger')

// NOTE:
// This is a *real* state container (persisted + versioned), even if the
// current detectors are best-effort / placeholders.
// When you add OCR/vision, only swap the "detectors" section.

const STATE_PATH = path.join(__dirname, '..', 'agent-game-state.json')

const DEFAULT_STATE = {
  schemaVersion: 1,
  lastUpdatedAt: null,
  // Session
  running: false,
  profile: 'new_account_rush',
  // Gameplay snapshot (best effort)
  resources: { food: null, wood: null, stone: null, iron: null, gold: null },
  shieldActive: null,
  stamina: null,
  buildQueue: { busy: null, finishesAt: null },
  researchQueue: { busy: null, finishesAt: null },
  mail: { hasRewards: null },
  tribe: { giftsAvailable: null, techContributionAvailable: null, r5AcceptPending: null },
  events: {
    leidolfInHiding: { active: null },
    cinderboneSoulburn: { active: null },
    festivalOfFlames: { active: null },
    rebatePack: { active: null },
    conquerTheIsland: { active: null },
  },
  chapters: { current: null, target: 17 },
  progression: {
    chiefHallLevel: null,
    prosperityLevel: null,
    expansionBuildLevel: null,
  },
  // Diagnostics
  lastActions: [],
  notes: [],
}

function safeReadJson(filePath) {
  try {
    if (!fs.existsSync(filePath)) return null
    return JSON.parse(fs.readFileSync(filePath, 'utf8'))
  } catch {
    return null
  }
}

function safeWriteJson(filePath, obj) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(obj, null, 2), 'utf8')
  } catch (e) {
    warn('failed_to_write_state', { error: String(e?.message || e) })
  }
}

class GameState {
  constructor() {
    this.state = { ...DEFAULT_STATE }
    const saved = safeReadJson(STATE_PATH)
    if (saved && saved.schemaVersion === DEFAULT_STATE.schemaVersion) {
      this.state = { ...this.state, ...saved }
      info('state_loaded', { path: STATE_PATH })
    }
  }

  getSnapshot() {
    return this.state
  }

  setRunning(running) {
    this.state.running = Boolean(running)
    this._touch()
  }

  setProfile(profile) {
    if (profile) this.state.profile = String(profile)
    this._touch()
  }

  recordAction(actionName, result) {
    const entry = { ts: new Date().toISOString(), actionName, result }
    this.state.lastActions = [entry, ...(this.state.lastActions || [])].slice(0, 50)
    this._touch()
  }

  addNote(note) {
    if (!note) return
    this.state.notes = [{ ts: new Date().toISOString(), note: String(note) }, ...(this.state.notes || [])].slice(0, 50)
    this._touch()
  }

  async refresh(detectors) {
    // Detectors are injected to keep this file stable.
    // Each detector returns partial state or null.
    if (!detectors) {
      this._touch()
      return this.state
    }

    const partials = await Promise.all(
      Object.entries(detectors).map(async ([name, fn]) => {
        try {
          const out = await fn(this.state)
          return out ? { name, out } : null
        } catch (e) {
          warn('detector_failed', { detector: name, error: String(e?.message || e) })
          return null
        }
      })
    )

    for (const p of partials.filter(Boolean)) {
      this.state = mergeDeep(this.state, p.out)
    }

    this._touch()
    return this.state
  }

  _touch() {
    this.state.lastUpdatedAt = new Date().toISOString()
    safeWriteJson(STATE_PATH, this.state)
  }
}

function isObject(x) {
  return x && typeof x === 'object' && !Array.isArray(x)
}

function mergeDeep(target, source) {
  if (!isObject(target) || !isObject(source)) return source
  const out = { ...target }
  for (const [k, v] of Object.entries(source)) {
    if (isObject(v) && isObject(out[k])) out[k] = mergeDeep(out[k], v)
    else out[k] = v
  }
  return out
}

module.exports = { GameState, STATE_PATH }

const { GameState } = require('./game-state')
const { TaskOrchestrator } = require('./orchestrator')
const { Humanizer } = require('./humanizer')
const { info, warn, error } = require('./logger')

// Detectors placeholder: wire OCR/vision here.
// Each detector returns partial state.
const DETECTORS = {
  // Example: return { shieldActive: true }
  noop: async (_state) => null,
}

class BotController {
  constructor(options = {}) {
    this.options = options
    this.state = new GameState()
    this.orchestrator = new TaskOrchestrator()
    this.human = new Humanizer(options.humanizer || {})
    this._timer = null
    this._running = false
    this._tickMs = options.tickMs ?? 5_000
  }

  getStatus() {
    const s = this.state.getSnapshot()
    return {
      running: this._running,
      profile: s.profile,
      lastUpdatedAt: s.lastUpdatedAt,
      lastAction: (s.lastActions || [])[0] || null,
    }
  }

  async getState() {
    // refresh snapshot (best effort)
    await this.state.refresh(DETECTORS)
    return this.state.getSnapshot()
  }

  async start({ profile } = {}) {
    if (this._running) return { started: false, reason: 'already_running' }
    if (profile) this.state.setProfile(profile)
    this._running = true
    this.state.setRunning(true)
    info('bot_started', { profile: this.state.getSnapshot().profile })
    this._timer = setInterval(() => this._tick().catch((e) => error('tick_failed', { error: String(e?.message || e) })), this._tickMs)
    // fire an immediate tick
    this._tick().catch(() => {})
    return { started: true }
  }

  async stop() {
    if (!this._running) return { stopped: false, reason: 'not_running' }
    this._running = false
    this.state.setRunning(false)
    if (this._timer) clearInterval(this._timer)
    this._timer = null
    info('bot_stopped')
    return { stopped: true }
  }

  async runOnce({ profile } = {}) {
    if (profile) this.state.setProfile(profile)
    return await this._tick({ once: true })
  }

  async _tick({ once } = {}) {
    // Refresh state snapshot first.
    await this.state.refresh(DETECTORS)
    const snapshot = this.state.getSnapshot()

    const { task, ctx } = this.orchestrator.pickNext(snapshot)
    if (!task) {
      if (once) return { ok: true, note: 'no_task_available' }
      return { ok: true, idle: true }
    }

    // Humanization: small pause + optional harmless detour
    await this.human.pause(`before_${task.name}`)
    const mistake = this.human.maybeMistake()
    if (mistake) {
      warn('human_mistake_simulated', mistake)
      await this.human.pause(`mistake_${mistake.type}`)
    }

    info('task_execute', { task: task.name })
    const result = await task.run(snapshot, ctx)
    this.state.recordAction(task.name, result)

    // Basic cooldown to avoid "perfect" looping.
    this.orchestrator.setCooldown(task.name)

    if (once) return { ok: true, task: task.name, result }
    return { ok: true, task: task.name }
  }
}

module.exports = { BotController }

const { getProfile } = require('./profiles')
const { info, warn } = require('./logger')

// Tasks
const { ShieldTask } = require('./tasks/shield')
const { RewardsTask } = require('./tasks/rewards')
const { HelpsTask } = require('./tasks/helps')
const { ConstructionTask } = require('./tasks/construction')
const { GatherTask } = require('./tasks/gather')

const TASKS = {
  shield: () => new ShieldTask(),
  rewards: () => new RewardsTask(),
  helps: () => new HelpsTask(),
  construction: () => new ConstructionTask(),
  gather: () => new GatherTask(),
}

class TaskOrchestrator {
  constructor(options = {}) {
    this.options = options
    this.cooldowns = new Map() // taskName -> unixMs
    this.defaultCooldownMs = options.defaultCooldownMs ?? 60_000
  }

  getContext(state) {
    const profile = getProfile(state.profile)
    return {
      profile,
      safety: {
        panicStop: Boolean(this.options.panicStop),
      },
      now: Date.now(),
    }
  }

  pickNext(state) {
    const ctx = this.getContext(state)
    const list = ctx.profile.priorities || []

    for (const taskName of list) {
      const factory = TASKS[taskName]
      if (!factory) {
        warn('unknown_task_in_profile', { taskName, profile: state.profile })
        continue
      }

      // cooldown check
      const until = this.cooldowns.get(taskName)
      if (until && until > ctx.now) continue

      const task = factory()
      if (task.canRun(state, ctx)) {
        return { task, ctx }
      }
    }

    return { task: null, ctx }
  }

  setCooldown(taskName, ms) {
    const until = Date.now() + (ms ?? this.defaultCooldownMs)
    this.cooldowns.set(taskName, until)
  }
}

module.exports = { TaskOrchestrator }

const { BaseTask } = require('./base-task')

class ConstructionTask extends BaseTask {
  constructor() {
    super('construction')
  }

  canRun(state, ctx) {
    if (ctx.safety?.panicStop) return false
    // do not start if build queue busy (if known)
    if (state.buildQueue?.busy === true) return false
    return true
  }

  async run(state, ctx) {
    const ch = state.progression?.chiefHallLevel
    const target = ctx.profile?.chiefHallTarget || 22
    const mode = ctx.profile?.chRush ? 'chief_hall_rush' : 'normal'
    return {
      ok: true,
      note: 'construction_planned',
      mode,
      chiefHall: { current: ch, target },
      policy: {
        buildOnlyRequired: Boolean(ctx.profile?.buildOnlyRequired),
        expansionHold: { level: ctx.profile?.expansionHoldLevel ?? 5, untilProsperity: ctx.profile?.expansionHoldUntilProsperity ?? 4 },
        speedups: ctx.profile?.speedups?.construction ?? 'allowed',
        eliteCostsExtra: Boolean(ctx.profile?.eliteCostsExtra),
      },
      visionRequired: true,
    }
  }
}

module.exports = { ConstructionTask }

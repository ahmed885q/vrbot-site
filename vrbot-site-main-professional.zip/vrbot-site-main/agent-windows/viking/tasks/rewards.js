const { BaseTask } = require('./base-task')

class RewardsTask extends BaseTask {
  constructor() {
    super('rewards')
  }

  canRun(_state, ctx) {
    return !ctx.safety?.panicStop
  }

  async run(state, ctx) {
    return {
      ok: true,
      note: 'rewards_planned',
      include: {
        daily: true,
        quest: true,
        chapter: true,
        mail: true,
        tribeGifts: true,
      },
      chapterTarget: state.chapters?.target ?? 17,
      visionRequired: true,
    }
  }
}

module.exports = { RewardsTask }

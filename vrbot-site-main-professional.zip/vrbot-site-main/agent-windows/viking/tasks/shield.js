const { BaseTask } = require('./base-task')

class ShieldTask extends BaseTask {
  constructor() {
    super('shield')
  }

  canRun(state, ctx) {
    if (ctx.safety?.panicStop) return false
    if (!ctx.profile?.useShield) return false
    // if already shielded, skip
    if (state.shieldActive === true) return false
    return true
  }

  async run(_state, ctx) {
    return { ok: true, note: 'shield_planned', duration: ctx.profile?.shieldDuration || '8h', visionRequired: true }
  }
}

module.exports = { ShieldTask }

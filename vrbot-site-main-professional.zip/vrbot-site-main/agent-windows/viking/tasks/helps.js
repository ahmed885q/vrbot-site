const { BaseTask } = require('./base-task')

class HelpsTask extends BaseTask {
  constructor() {
    super('helps')
  }

  canRun(state, ctx) {
    if (ctx.safety?.panicStop) return false
    // If tribe data unknown, still allow but mark vision
    return true
  }

  async run(_state, _ctx) {
    return { ok: true, note: 'helps_planned', visionRequired: true }
  }
}

module.exports = { HelpsTask }

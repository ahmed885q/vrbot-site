const { BaseTask } = require('./base-task')

class GatherTask extends BaseTask {
  constructor() {
    super('gather')
  }

  canRun(state, ctx) {
    // Example guardrails:
    // - avoid if shield policy says "stay shielded and idle"
    // - avoid if resources are unknown (requires vision)
    if (ctx.safety?.panicStop) return false
    if (state.shieldActive === true && ctx.profile?.preferSafeUnderShield) return false
    return true
  }

  async run(state, ctx) {
    // PLACEHOLDER: replace with actual UI automation (vision + input)
    return {
      ok: true,
      note: 'gather_planned',
      target: ctx.profile?.gatherTarget || 'best_available',
      visionRequired: true,
      stateSummary: {
        resourcesKnown: Object.values(state.resources || {}).every((v) => typeof v === 'number'),
      },
    }
  }
}

module.exports = { GatherTask }

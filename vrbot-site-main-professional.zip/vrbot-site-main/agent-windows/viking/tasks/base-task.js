class BaseTask {
  constructor(name) {
    this.name = name
  }

  // Return boolean
  canRun(_state, _ctx) {
    return false
  }

  // Must return { ok: boolean, ... }
  async run(_state, _ctx) {
    return { ok: false, reason: 'not_implemented' }
  }
}

module.exports = { BaseTask }

// Humanization layer for anti-detection.
// This is intentionally *small* and dependency-free.

function rand(min, max) {
  return Math.random() * (max - min) + min
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

class Humanizer {
  constructor(options = {}) {
    this.errorRate = options.errorRate ?? 0.02 // 2%
    this.jitterMs = options.jitterMs ?? 250
    this.minDelayMs = options.minDelayMs ?? 150
    this.maxDelayMs = options.maxDelayMs ?? 900
  }

  async pause(label) {
    const base = rand(this.minDelayMs, this.maxDelayMs)
    const jitter = rand(0, this.jitterMs)
    await sleep(base + jitter)
    return { label, sleptMs: Math.round(base + jitter) }
  }

  maybeMistake() {
    // Return a "mistake" object rarely, for the caller to simulate harmless detours.
    if (Math.random() > this.errorRate) return null
    const mistakes = [
      { type: 'extra_back', note: 'pressed back once' },
      { type: 'open_close_panel', note: 'opened a wrong panel then closed' },
      { type: 'idle_pause', note: 'paused briefly' },
    ]
    return mistakes[Math.floor(Math.random() * mistakes.length)]
  }
}

module.exports = { Humanizer, sleep, rand }

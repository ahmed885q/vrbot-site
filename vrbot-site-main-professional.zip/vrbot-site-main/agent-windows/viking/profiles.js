// Strategy profiles define priorities + policies.
// You can add more profiles without touching the orchestrator.

const PROFILES = {
  new_account_rush: {
    name: 'New Account Rush',
    chRush: true,
    chiefHallTarget: 22,
    buildOnlyRequired: true,
    eliteCostsExtra: true,
    expansionHoldLevel: 5,
    expansionHoldUntilProsperity: 4,
    speedups: {
      construction: 'allowed',
      research: 'allowed',
      divination: 'speedups_only',
    },
    useShield: true,
    shieldDuration: '8h',
    preferSafeUnderShield: false,
    // Priority list: top → first
    priorities: [
      'shield',
      'rewards',
      'helps',
      'construction',
      'gather',
    ],
  },
  safe_mode: {
    name: 'Safe Mode',
    chRush: false,
    buildOnlyRequired: true,
    useShield: true,
    preferSafeUnderShield: true,
    priorities: ['shield', 'rewards', 'helps', 'construction'],
  },
}

function getProfile(key) {
  return PROFILES[key] || PROFILES.new_account_rush
}

module.exports = { PROFILES, getProfile }

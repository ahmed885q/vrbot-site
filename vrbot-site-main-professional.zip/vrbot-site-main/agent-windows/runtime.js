// Professional Windows Agent runtime entrypoint
// --------------------------------------------
// Starts:
//   1) Local Control API (http://127.0.0.1:9797)
//   2) Optional streaming (MediaMTX + ffmpeg) via /stream/*
//   3) Viking Rise bot controller (orchestrator + state + humanization)
//
// This runtime is intentionally "headless".
// The UI (Next app) can call the local endpoints through WindowsAgentService.

const { StreamManager } = require('./streaming')
const { startControlServer } = require('./control-server')
const { BotController } = require('./viking/bot-controller')
const { info } = require('./viking/logger')

async function main() {
  info('runtime_start')
  const streams = new StreamManager()
  const bot = new BotController({
    tickMs: 5_000,
    humanizer: { errorRate: 0.02 },
  })

  // Start control server (stream + bot)
  startControlServer(streams, bot, 9797)

  // Graceful shutdown
  const shutdown = async () => {
    info('runtime_shutdown')
    try { await bot.stop() } catch {}
    try { streams.stopAll() } catch {}
    process.exit(0)
  }
  process.on('SIGINT', shutdown)
  process.on('SIGTERM', shutdown)
}

if (require.main === module) {
  main().catch((e) => {
    console.error('runtime failed:', e)
    process.exit(1)
  })
}

Windows Agent (Viking Rise)
==========================

Quick start (local control API)
-------------------------------
1) Install Node.js (>=18) on Windows
2) Open CMD / PowerShell
3) cd to this folder (agent-windows)
4) Run the runtime:
   node runtime.js

This will start a local API at:
  http://127.0.0.1:9797

Useful endpoints:
  GET  /health
  GET  /state
  GET  /bot/status
  POST /bot/start      body: { "profile": "new_account_rush" }
  POST /bot/stop
  POST /bot/run-once

Backwards compatible endpoints (older UI):
  GET  /viking/status
  GET  /viking/state
  POST /viking/start
  POST /viking/stop
  POST /viking/execute

Optional server registration (heartbeat)
--------------------------------------
If you want the agent to register & send heartbeats to your Next.js server,
run:
  node agent.js

Notes
-----
* The current bot controller is a professional orchestrator framework.
  It logs decisions, enforces cooldowns, and keeps a persisted GameState.
* To make it execute real gameplay, wire OCR/vision detectors and input actions
  in: agent-windows/viking/bot-controller.js

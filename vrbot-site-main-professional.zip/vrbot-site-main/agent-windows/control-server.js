const http = require('http')
const { URL } = require('url')

// Bot control API
// ----------------
// This file used to expose only /stream/*.
// We extend it to expose a stable local API for the Windows Agent runtime:
//   - GET  /health
//   - GET  /state
//   - GET  /bot/status
//   - POST /bot/start
//   - POST /bot/stop
//   - POST /bot/run-once
// While keeping /stream/* endpoints unchanged.

function readBody(req) {
  return new Promise((resolve) => {
    let data = ''
    req.on('data', (chunk) => (data += chunk))
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {})
      } catch {
        resolve({})
      }
    })
  })
}

/**
 * streams: StreamManager من streaming.js
 * port: افتراضي 9797
 */
function startControlServer(streams, botController, port = 9797) {
  const server = http.createServer(async (req, res) => {
    // CORS بسيط للـ localhost
    res.setHeader('Access-Control-Allow-Origin', '*')
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

    if (req.method === 'OPTIONS') {
      res.writeHead(204)
      return res.end()
    }

    try {
      const url = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`)

      // Health
      if (req.method === 'GET' && url.pathname === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, service: 'windows-agent', ts: new Date().toISOString() }))
      }

      // State snapshot (best-effort)
      if (req.method === 'GET' && url.pathname === '/state') {
        const state = botController ? await botController.getState() : { note: 'botController not wired' }
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, state }))
      }

      // Bot status
      if (req.method === 'GET' && url.pathname === '/bot/status') {
        const status = botController ? botController.getStatus() : { running: false, note: 'botController not wired' }
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, status }))
      }

      // Backwards-compatible aliases (older UI expects /viking/*)
      if (req.method === 'GET' && url.pathname === '/viking/status') {
        const status = botController ? botController.getStatus() : { running: false, note: 'botController not wired' }
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, status }))
      }

      if (req.method === 'GET' && url.pathname === '/viking/state') {
        const state = botController ? await botController.getState() : { note: 'botController not wired' }
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, state }))
      }

      // Bot controls
      if (req.method === 'POST' && url.pathname === '/bot/start') {
        const body = await readBody(req)
        if (!botController) throw new Error('botController not wired')
        const out = await botController.start(body || {})
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, result: out }))
      }

      if (req.method === 'POST' && url.pathname === '/viking/start') {
        const body = await readBody(req)
        if (!botController) throw new Error('botController not wired')
        const out = await botController.start(body || {})
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, result: out }))
      }

      if (req.method === 'POST' && url.pathname === '/bot/stop') {
        const body = await readBody(req)
        if (!botController) throw new Error('botController not wired')
        const out = await botController.stop(body || {})
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, result: out }))
      }

      if (req.method === 'POST' && url.pathname === '/viking/stop') {
        const body = await readBody(req)
        if (!botController) throw new Error('botController not wired')
        const out = await botController.stop(body || {})
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, result: out }))
      }

      if (req.method === 'POST' && url.pathname === '/bot/run-once') {
        const body = await readBody(req)
        if (!botController) throw new Error('botController not wired')
        const out = await botController.runOnce(body || {})
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, result: out }))
      }

      if (req.method === 'POST' && url.pathname === '/viking/execute') {
        // Legacy endpoint: we translate taskType into a single tick.
        const body = await readBody(req)
        if (!botController) throw new Error('botController not wired')
        // If profile is provided we accept it; otherwise run once using current profile.
        const out = await botController.runOnce({ profile: body?.profile })
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, result: out }))
      }

      if (req.method === 'GET' && url.pathname === '/viking/bots') {
        const status = botController ? botController.getStatus() : { running: false }
        // Single-controller model for now.
        const bots = [
          {
            id: 'local-bot',
            name: 'Viking Rise',
            windowTitle: 'Viking Rise',
            deviceId: 'local',
            gameAccount: 'unknown',
            status: status.running ? 'active' : 'inactive',
            totalActions: 0,
            successRate: 1.0,
          },
        ]
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, bots }))
      }

      if (req.method === 'POST' && req.url === '/stream/start') {
        await readBody(req) // (حاليًا غير مستخدمة)
        streams.startAll()
        const status = streams.getStatus()
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, status }))
      }

      if (req.method === 'POST' && req.url === '/stream/stop') {
        await readBody(req)
        streams.stopAll()
        const status = streams.getStatus()
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, status }))
      }

      if (req.method === 'GET' && req.url === '/stream/status') {
        const status = streams.getStatus()
        res.writeHead(200, { 'Content-Type': 'application/json' })
        return res.end(JSON.stringify({ ok: true, status }))
      }

      res.writeHead(404, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ ok: false, error: 'Not found' }))
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ ok: false, error: String(e?.message || e) }))
    }
  })

  server.listen(port, '127.0.0.1', () => {
    console.log(`[control] listening on http://127.0.0.1:${port}`)
  })

  return server
}

module.exports = { startControlServer }
